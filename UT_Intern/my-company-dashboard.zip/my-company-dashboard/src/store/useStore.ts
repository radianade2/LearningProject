// src/store/useBearFamilyMealsStore.ts
import { create } from 'zustand';

type BearFamilyMealsStore = {
  papaBear: string;
  mamaBear: string;
  babyBear: string;
};

const useBearFamilyMealsStore = create<BearFamilyMealsStore>(() => ({
  papaBear: 'large porridge pot',
  mamaBear: 'middle-size porridge pot',
  babyBear: 'a little, small, wee pot',
}));

export default useBearFamilyMealsStore;