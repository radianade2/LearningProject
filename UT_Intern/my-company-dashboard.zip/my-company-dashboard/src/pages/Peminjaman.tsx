// src/components/BearFamilyMeals.tsx
import React from 'react';
import useBearFamilyMealsStore from '../store/useStore';

const BearFamilyMeals: React.FC = () => {
  const { papaBear, mamaBear, babyBear } = useBearFamilyMealsStore();

  return (
    <div style={{ textAlign: 'center', margin: '20px' }}>
      <h1>Bear Family Meals</h1>
      <p>Papa Bear's Meal: {papaBear}</p>
      <p>Mama Bear's Meal: {mamaBear}</p>
      <p>Baby Bear's Meal: {babyBear}</p>
    </div>
  );
};

export default BearFamilyMeals;